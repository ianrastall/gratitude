"""Exercise an offline rebuild twice and prove that curator edits survive."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT.parent / 'work'


def digests(path):
    return {p.relative_to(path).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in path.rglob('*.xml')}


def main():
    WORK.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='berthaml-rebuild-', dir=WORK) as temp:
        target = Path(temp).resolve()
        if not target.is_relative_to(WORK.resolve()):
            raise ValueError('temporary rebuild escaped the workspace')
        data = target / 'data'
        shutil.copytree(ROOT / 'data', data)
        out = target / 'curation'
        out.mkdir()
        ledger = out / 'import-ledger.json'
        shutil.copyfile(ROOT / 'curation/import-ledger.json', ledger)
        command = [sys.executable, str(ROOT / 'tools/populate.py'), '--data', str(data), '--ledger', str(ledger)]
        before = digests(data)
        subprocess.run(command, check=True)
        assert before == digests(data), 'offline rebuild changed XML without a source change'
        managed = json.loads(ledger.read_text(encoding='utf-8'))['generated_files']
        edited = data / next(iter(managed))
        edited.write_bytes(edited.read_bytes().replace(b'</show>', b'<!-- curator edit survives -->\n</show>'))
        registry = data / 'songs.xml'
        registry.write_bytes(registry.read_bytes().replace(b'</songs>', b'<!-- curator registry edit survives -->\n</songs>'))
        expected_show, expected_registry = edited.read_bytes(), registry.read_bytes()
        sample = (data / 'shows/1970/gd1970-05-02.xml').read_bytes()
        subprocess.run(command, check=True)
        assert edited.read_bytes() == expected_show, 'curator show edit overwritten'
        assert registry.read_bytes() == expected_registry, 'curator registry edit overwritten'
        assert (data / 'shows/1970/gd1970-05-02.xml').read_bytes() == sample, 'supplied sample overwritten'
        subprocess.run([sys.executable, str(ROOT / 'tools/validate.py'), str(data), '--strict'], check=True)
        print('Offline rebuild deterministic; curator show/registry edits and supplied sample preserved.')


if __name__ == '__main__':
    main()
