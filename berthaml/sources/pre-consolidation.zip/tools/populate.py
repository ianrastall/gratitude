"""Build the 1967-1995 research corpus offline, preserving every edited file.

Imports are drafts, not certifications. Source snapshots and identity conflicts
remain available separately from the XML. Run audit.py after making corrections.
"""
import argparse
from collections import Counter, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import re
from datetime import date

from lxml import etree as E

from collect_index import fingerprint, normalize

ROOT = Path(__file__).resolve().parents[1]
NS = 'urn:berthaml:1'
N = {'b': NS}
UPDATED = '2026-10-30'
COUNTRIES = dict(US='US', Canada='CA', England='GB', Scotland='GB', Germany='DE',
                 France='FR', Denmark='DK', Netherlands='NL', Egypt='EG',
                 Luxembourg='LU', Spain='ES', Jamaica='JM', Sweden='SE')
# Explicit spelling repairs supported by the independently captured index.
# Raw source spellings remain in the licensed snapshot and the identity ledger.
VENUE_REPAIRS = {
    'Caf\ufffd au Go-Go': 'Café au Go-Go',
    'Walter K\ufffdbel Halle': 'Walter Köbel Halle',
    'Z\ufffdnith Paris': 'Zénith Paris',
    'Dean E. Smith Center, Unversity of North Carolina':
        'Dean E. Smith Center, University of North Carolina',
}


def q(tag):
    return '{' + NS + '}' + tag


def add(parent, tag, text=None, **attrs):
    el = E.SubElement(parent, q(tag), **{k: str(v) for k, v in attrs.items()})
    el.text = text
    return el


def sha(data):
    return hashlib.sha256(data).hexdigest()


def xml(root):
    return E.tostring(root, encoding='UTF-8', xml_declaration=True, pretty_print=True)


def json_file(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def day_of(label):
    day = label[:10].replace('/', '-')
    if day.endswith('-00'):
        day = day[:-3]
    if day.endswith('-00'):
        day = day[:-3]
    return day


def gd_fingerprint(row):
    return fingerprint(''.join(song[':name'] for st in row[':sets'] for song in st[':songs']))


def recording_date(row):
    value = row['key'] if row['provider'] == 'Archive.org' else row['title']
    match = re.search(r'(?i)gd((?:19)?\d{2})[-_.](\d{2})[-_.](\d{2})', value)
    if not match:
        return None
    y, m, d = map(int, match.groups())
    y = y + 1900 if y < 100 else y
    try:
        day = date(y, m, d).isoformat()
    except ValueError:
        return None
    return day if '1967-01-01' <= day <= '1995-07-09' else None


def place_recordings(planned, rows):
    by_date = defaultdict(list)
    parsed = {path: E.fromstring(content) for path, content in planned.items()}
    for path, root in parsed.items():
        if len(root.get('date')) == 10 and root.get('dateCertainty') != 'uncertain':
            by_date[root.get('date')].append(path)
    placements = []
    kinds = dict(SBD='soundboard', AUD='audience', MTX='matrix', FM='fm', UNKNOWN='unknown')
    for row in rows:
        day = recording_date(row)
        paths = by_date.get(day, [])
        reason = None
        if day is None:
            reason = 'identifier-date-unknown-or-out-of-scope'
        elif day != row['grouped_date']:
            reason = 'identifier-date-disagrees-with-runtime-group'
        elif len(paths) != 1:
            reason = 'multiple-shows-on-date' if len(paths) > 1 else 'no-confirmed-date-entry'
        entry = dict(provider=row['provider'], key=row['key'], identifier_date=day,
                     original_grouped_date=row['grouped_date'], reason=reason,
                     proposed_show=parsed[paths[0]].get('id') if not reason else None)
        placements.append(entry)
        if reason:
            continue
        root = parsed[paths[0]]
        sources = root.find('b:sources', N)
        if sources is None:
            sources = E.Element(q('sources'))
            root.insert(list(root).index(root.find('b:program', N)) + 1, sources)
        rid = 'rec-' + sha((row['provider'] + ':' + row['key']).encode())[:20]
        rec = add(sources, 'recording', id=rid, kind=kinds[row['type']])
        add(rec, 'identifier', row['key'], scheme='archive-org' if row['provider'] == 'Archive.org' else 'other')
        lineage = ' | '.join(x for x in (row['source_chain'], row['lineage']) if x)
        if lineage:
            add(rec, 'lineage', lineage)
        add(rec, 'note', 'Historical provider listing matched by explicit identifier date only. '
            'Tape identity, source classification, credits and coverage await review; current availability is untested.')
        if row.get('inferredType') == 'true':
            add(rec, 'note', 'Recording kind was inferred in the source catalogue.', certainty='uncertain')
        if row.get('modifiers'):
            add(rec, 'note', 'Source catalogue modifiers: ' + row['modifiers'])
        for credit in row['credits']:
            add(rec, 'note', f'Unadjudicated source credit ({credit["role"]}): {credit["text"]}')
        for person in row['people']:
            add(rec, 'note', 'Unadjudicated source person: ' + json.dumps(person, ensure_ascii=False, sort_keys=True))
        note = f'Input {row["provider"]} key {row["key"]}; provenance {row.get("sourceRefs", "")}; snapshot 2026-10-29.'
        add(rec, 'note', note)
    for path, root in parsed.items():
        planned[path] = xml(root)
    return placements


def reconcile(rows, index):
    """Unique factual identity first; ambiguous same-venue shows remain groups.

    A zero-based source position is never translated into an early/late claim.
    A program fingerprint may distinguish two candidates but never changes songs.
    """
    by_day = defaultdict(list)
    for item in index:
        if item['category'] == 'Public':
            by_day[day_of(item['date_label'])].append(item)
    candidates, assigned, used = {}, {}, set()
    for row in rows:
        venue = normalize(VENUE_REPAIRS.get(row[':venue'], row[':venue']))
        candidates[row[':uuid']] = [i for i in by_day[day_of(row['key'])]
                                    if normalize(i['venue_label']).startswith(venue)]
    changed = True
    while changed:
        changed = False
        for row in rows:
            uid = row[':uuid']
            if uid in assigned:
                continue
            possible = [i for i in candidates[uid] if i['url'] not in used]
            sig = gd_fingerprint(row)
            exact = [i for i in possible if sig and i['program_fingerprint'] == sig]
            if len(exact) == 1:
                possible = exact
            # Do not choose a contested singleton on behalf of another source row.
            if len(possible) == 1:
                target = possible[0]
                peers = [r for r in rows if r[':uuid'] not in assigned and
                         target in candidates[r[':uuid']]]
                if len(peers) > 1:
                    exact_peers = [r for r in peers if gd_fingerprint(r) and
                                   gd_fingerprint(r) == target['program_fingerprint']]
                    if len(exact_peers) != 1 or exact_peers[0][':uuid'] != uid:
                        continue
                assigned[uid] = target
                used.add(target['url'])
                changed = True
    groups = defaultdict(list)
    for row in rows:
        uid = row[':uuid']
        if uid not in assigned:
            remaining = tuple(sorted(i['url'] for i in candidates[uid] if i['url'] not in used))
            if remaining:
                groups[remaining].append(uid)
    grouped = {}
    for urls, uids in groups.items():
        if len(urls) != len(uids):
            raise ValueError(f'Unresolved identity cardinality: {urls}: {uids}')
        for uid in uids:
            grouped[uid] = list(urls)
        used.update(urls)
    supplements = [i for i in index if i['category'] == 'Public' and i['url'] not in used]
    return assigned, grouped, supplements


class Registry:
    def __init__(self, path, item_tag, name_tag, prefix):
        self.path = path
        self.root = E.parse(str(path)).getroot()
        self.original = path.read_bytes()
        self.item_tag, self.name_tag, self.prefix = item_tag, name_tag, prefix
        self.ids = {el.get('id') for el in self.root.findall('b:' + item_tag, N)}
        self.names = {}
        for item in self.root.findall('b:' + item_tag, N):
            names = item.findall('b:' + name_tag, N) + item.findall('b:altTitle', N)
            for name in names:
                self.names.setdefault(normalize(name.text or ''), []).append(item)

    def new_id(self, label, discriminator=''):
        import unicodedata
        ascii_label = unicodedata.normalize('NFKD', label).encode('ascii', 'ignore').decode().lower()
        stem = re.sub('[^a-z0-9]+', '-', ascii_label).strip('-') or 'unknown'
        result = self.prefix + stem
        if result in self.ids:
            result += '-' + sha((label + discriminator).encode())[:10]
        if result in self.ids:
            raise ValueError(f'registry ID collision: {result}')
        self.ids.add(result)
        return result

    def song(self, title):
        candidates = self.names.get(normalize(title), [])
        if len(candidates) == 1:
            return candidates[0].get('id')
        if candidates:
            raise ValueError(f'ambiguous seed song: {title}')
        entry = add(self.root, 'song', id=self.new_id(title), kind='unknown')
        add(entry, 'title', title)
        add(entry, 'note', 'Imported source title. Classification, writer credits and lead vocals await review.')
        self.names[normalize(title)] = [entry]
        return entry.get('id')

    def venue(self, name, city='', region='', country='', source_url=''):
        for entry in self.names.get(normalize(name), []):
            loc = entry.find('b:locality', N)
            if all(normalize(loc.get(k, '')) == normalize(v)
                   for k, v in dict(city=city, region=region, country=country).items()):
                return entry.get('id')
        discriminator = '|'.join((city, region, country, source_url))
        entry = add(self.root, 'venue', id=self.new_id(name + (' ' + city if city else ''), discriminator))
        add(entry, 'name', name)
        add(entry, 'locality', **{k: v for k, v in dict(city=city, region=region, country=country).items() if v})
        add(entry, 'note', 'Imported venue identity; physical-site aliases, dated names and coordinates await review.'
            + (f' Evidence: {source_url}' if source_url else ''))
        self.names.setdefault(normalize(name), []).append(entry)
        return entry.get('id')


def source_cite(record, title, href, text):
    add(record, 'cite', text, title=title, href=href, accessed=UPDATED)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, default=ROOT / 'data')
    parser.add_argument('--ledger', type=Path, default=ROOT / 'curation' / 'import-ledger.json')
    args = parser.parse_args()
    payload = gzip.decompress((ROOT / 'sources' / 'gdshowsdb.json.gz').read_bytes())
    lock = json.loads((ROOT / 'sources' / 'gdshowsdb-lock.json').read_text(encoding='utf-8'))
    if sha(payload) != lock['facts_sha256']:
        raise ValueError('gdshowsdb input checksum mismatch')
    rows = json.loads(payload)
    if len(rows) != lock['records'] or len({r[':uuid'] for r in rows}) != len(rows):
        raise ValueError('source count/UUID integrity failure')
    index = json.loads((ROOT / 'sources' / 'jerrybase-index.json').read_text(encoding='utf-8'))['events']
    assigned, grouped, supplements = reconcile(rows, index)
    data = args.data.resolve()
    songs = Registry(data / 'songs.xml', 'song', 'title', 's-')
    venues = Registry(data / 'venues.xml', 'venue', 'name', 'v-')
    previous = json.loads(args.ledger.read_text(encoding='utf-8')) if args.ledger.exists() else {}
    managed = previous.get('generated_files', {})
    planned, ledger = {}, []
    dates = Counter(day_of(r['key']) for r in rows)
    dates.update(day_of(i['date_label']) for i in supplements)
    rev = lock['revision']
    for row in rows:
        day, uid = day_of(row['key']), row[':uuid']
        sid = 'gd' + day + ('-g' + uid.replace('-', '')[:12] if dates[day] > 1 else '')
        root = E.Element(q('show'), nsmap={None: NS}, id=sid, date=day, schemaVersion='1.0')
        known = assigned.get(uid)
        group_urls = grouped.get(uid, [])
        if not known and not group_urls:
            root.set('dateCertainty', 'uncertain')
        record = add(root, 'record', status='draft' if row[':sets'] else 'skeleton', updated=UPDATED)
        source_cite(record, f'gdshowsdb {row["key"]} (MIT), UUID {uid}',
                    f'https://github.com/jefmsmit/gdshowsdb/blob/{rev}/data/gdshowsdb/{day[:4]}.yaml',
                    'Imported date, location, ordered sets and song titles. False segue flags do not establish stops. '
                    'Set roles, modes, lineup and completeness were not supplied.')
        if known:
            source_cite(record, 'Jerrybase public-event identity', known['url'],
                        'Independent identity-index comparison; no claim of independent source lineage.')
        elif group_urls:
            for url in group_urls:
                source_cite(record, 'Jerrybase same-date/venue identity group', url,
                            'Group evidence only. Assignment of this source record to an individual event is unresolved.')
        if dates[day] > 1:
            slot = 'unknown'
            if known:
                for value in ('Early', 'Late', 'Afternoon', 'Evening'):
                    if re.search(r'\b' + value + r'\b', known['date_label']):
                        slot = value.lower()
            add(root, 'slot', slot)
        name = VENUE_REPAIRS.get(row[':venue'], row[':venue'])
        country = COUNTRIES[row[':country']]
        venue_id = venues.venue(name, row[':city'] or '', row[':state'] or '', country,
                                known['venue_url'] if known else '')
        add(root, 'venue', ref=venue_id)
        program = add(root, 'program', coverage='partial' if row[':sets'] else 'none')
        for sn, st in enumerate(row[':sets'], 1):
            set_el = add(program, 'set', kind='unknown', n=sn, mode='unknown')
            for pn, song in enumerate(st[':songs'], 1):
                song_id = songs.song(song[':name'])
                canonical = next(s for s in songs.root.findall('b:song', N) if s.get('id') == song_id)
                variant = {} if canonical.findtext('b:title', namespaces=N) == song[':name'] else {'titleVariant': song[':name']}
                add(set_el, 'performance', id=f's{sn}-{pn:02}', song=song_id,
                    transition='segue' if song[':segued'] else 'unknown', **variant)
        performances = root.findall('.//b:performance', N)
        terminal_segue = bool(performances and performances[-1].get('transition') == 'segue')
        if terminal_segue:
            performances[-1].set('transition', 'unknown')
            add(root, 'note', 'The source marks its final song as a segue without supplying a following song. '
                'The on-stage transition remains unknown pending review.', certainty='uncertain')
        add(root, 'note', 'Unreviewed import. Missing lineup means unresearched personnel. '
            'Program coverage is conservatively partial; source set boundaries are retained without inferring encores, '
            'acoustic modes, reprises, on-stage personnel or recording durations.')
        if group_urls:
            add(root, 'note', 'Two same-date/venue source records are retained separately. '
                'The individual Jerrybase event association and show slot remain unresolved.')
        if not known and not group_urls:
            add(root, 'note', 'This source event was not located in the captured Jerrybase public-event index. '
                'Occurrence/date/venue require adjudication before inclusion in a verified concert count.', certainty='uncertain')
        if name != row[':venue']:
            add(root, 'note', f'Source venue spelling repaired using Jerrybase identity evidence. Raw value: {row[":venue"]}')
        relative = f'shows/{day[:4]}/{sid}.xml'
        planned[relative] = xml(root)
        ledger.append(dict(show=sid, path=relative, source='gdshowsdb', source_key=row['key'], source_uuid=uid,
                           source_performances=sum(len(st[':songs']) for st in row[':sets']),
                           jerrybase_url=known['url'] if known else None, identity_group=group_urls,
                           program_agrees=(gd_fingerprint(row) == known['program_fingerprint']) if known else None,
                           source_terminal_segue=terminal_segue,
                           identity_unconfirmed=not known and not group_urls))
    for item in supplements:
        day = day_of(item['date_label'])
        parts = day.split('-')
        sid = 'gd' + parts[0] + '-' + (parts[1] if len(parts) > 1 else 'xx') + '-' + (parts[2] if len(parts) > 2 else 'xx')
        if dates[day] > 1:
            sid += '-j' + item['url'].rsplit('-', 1)[1]
        root = E.Element(q('show'), nsmap={None: NS}, id=sid, date=day, schemaVersion='1.0')
        if len(parts) < 3:
            root.set('dateCertainty', 'uncertain')
        rec = add(root, 'record', status='skeleton', updated=UPDATED)
        source_cite(rec, 'Jerrybase public-event index', item['url'],
                    'Public GD event identity. Displayed zero day means unknown day; URL date is not evidence of the first day of the month.')
        if dates[day] > 1:
            add(root, 'slot', next((s.lower() for s in ('Early', 'Late', 'Afternoon', 'Evening') if s in item['date_label']), 'unknown'))
        # A label is retained verbatim until its structured locality has evidence.
        vid = venues.venue(item['venue_label'], source_url=item['venue_url'])
        add(root, 'venue', ref=vid)
        add(root, 'program', coverage='none')
        add(root, 'note', 'Index-only event. Venue label retained verbatim; structured locality, personnel and setlist await research. '
            + ('The index has song information that has not yet been transcribed.' if item['program_fingerprint'] else 'No song list supplied in the index.'))
        relative = f'shows/{day[:4]}/{sid}.xml'
        if relative in planned:
            raise ValueError(f'duplicate planned path: {relative}')
        planned[relative] = xml(root)
        ledger.append(dict(show=sid, path=relative, source='jerrybase-index', jerrybase_url=item['url'],
                           source_performances=0, program_available=bool(item['program_fingerprint']),
                           identity_group=[], identity_unconfirmed=False))
    rec_payload = gzip.decompress((ROOT / 'sources' / 'recordings.json.gz').read_bytes())
    rec_lock = json.loads((ROOT / 'sources' / 'recordings-lock.json').read_text(encoding='utf-8'))
    if sha(rec_payload) != rec_lock['facts_sha256']:
        raise ValueError('recording snapshot checksum mismatch')
    placements = place_recordings(planned, json.loads(rec_payload))
    # Preflight every path before mutation. An edited XML is always retained.
    stale = set(managed) - set(planned)
    if stale:
        raise ValueError(f'source update would orphan existing identities: {sorted(stale)}')
    generated, preserved = {}, []
    for relative, content in planned.items():
        path = data / relative
        if path.exists() and (relative not in managed or sha(path.read_bytes()) != managed[relative]):
            preserved.append(relative)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
            generated[relative] = sha(content)
    for registry in (songs, venues):
        # Appending missing IDs preserves seed facts and later curator edits.
        registry.path.write_bytes(xml(registry.root))
    for entry in ledger:
        entry['preserved_existing'] = entry['path'] in preserved
    json_file(args.ledger, dict(schema=1, imported=UPDATED, gdshowsdb_revision=rev,
                                generated_files=generated, preserved_files=preserved, shows=ledger,
                                index_categories=dict(Counter(i['category'] for i in index)),
                                index_public_events=sum(i['category'] == 'Public' for i in index)))
    for entry in placements:
        if entry['proposed_show']:
            match = next(s for s in ledger if s['show'] == entry['proposed_show'])
            if match['preserved_existing']:
                entry['reason'] = 'existing-curated-file-preserved'
                entry['proposed_show'] = None
    (args.ledger.parent / 'recording-placement.json.gz').write_bytes(gzip.compress(
        json.dumps(placements, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode(), mtime=0))
    print(f'{len(planned)} shows; {len(preserved)} existing edited/seed files preserved; '
          f'{len(assigned)} individual identities matched; {len(grouped)} source records in unresolved identity groups; '
          f'{len(supplements)} index supplements.')


if __name__ == '__main__':
    main()
