"""Snapshot factual recording references from Gratitude's existing offline XML.

No audio, review prose, source rankings or recording availability is collected.
Date placement is independently checked against each original identifier/title.
"""
import gzip
import hashlib
import json
from pathlib import Path

from lxml import etree as E

ROOT = Path(__file__).resolve().parents[1]


def main():
    path = ROOT.parent / 'data' / 'gd-shows.xml'
    data = path.read_bytes()
    root = E.fromstring(data)
    rows = []
    for show in root.findall('shows/show'):
        for rec in show.findall('recording'):
            rows.append(dict(grouped_date=show.get('date'), **dict(rec.attrib),
                             source_chain=rec.findtext('sourceChain') or '',
                             lineage=rec.findtext('lineage') or '',
                             credits=[dict(role=c.get('role'), text=c.text or '')
                                      for c in rec.findall('creditText')],
                             people=[dict(p.attrib) for p in rec.findall('person')]))
    if len({(r['provider'], r['key']) for r in rows}) != len(rows):
        raise ValueError('duplicate provider recording keys')
    payload = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
    sources = ROOT / 'sources'
    (sources / 'recordings.json.gz').write_bytes(gzip.compress(payload, mtime=0))
    (sources / 'recordings-lock.json').write_text(json.dumps(dict(
        source='../../data/gd-shows.xml', source_sha256=hashlib.sha256(data).hexdigest(),
        captured=root.get('capturedDate'), records=len(rows),
        facts_sha256=hashlib.sha256(payload).hexdigest(),
        provenance=[dict(s.attrib) for s in root.findall('sources/source')]), indent=2) + '\n', encoding='utf-8')
    print(f'{len(rows)} historical recording references captured')


if __name__ == '__main__':
    main()
