"""Integrity checks for import identity, uncertainty and source conservation."""
from collections import Counter
import gzip
import json
from pathlib import Path
import unittest

from lxml import etree as E

from collect_index import fingerprint, parse
from populate import N, ROOT, day_of, recording_date, reconcile, sha


def source(uid, key='1969/01/01', venue='Venue', songs=()):
    return {':uuid': uid, 'key': key, ':venue': venue, ':city': 'City',
            ':sets': [{':songs': [{':name': s} for s in songs]}] if songs else []}


def event(uid, venue='Venue, City', songs=()):
    return dict(date_label='1969-01-01', venue_label=venue, category='Public',
                url='https://example.org/' + uid, program_fingerprint=fingerprint(''.join(songs)))


class IdentityTests(unittest.TestCase):
    def test_same_date_different_venues(self):
        rows = [source('a', venue='Hall'), source('b', venue='Park')]
        matched, grouped, extra = reconcile(rows, [event('x', 'Park, City'), event('y', 'Hall, City')])
        self.assertEqual(matched['a']['url'], 'https://example.org/y')
        self.assertEqual(matched['b']['url'], 'https://example.org/x')
        self.assertFalse(grouped or extra)

    def test_ambiguous_programs_do_not_invent_early_late(self):
        for songs in [(), ('Bertha',)]:
            rows = [source('a', songs=songs), source('b', songs=songs)]
            matched, grouped, extra = reconcile(rows, [event('x', songs=songs), event('y', songs=songs)])
            self.assertFalse(matched or extra)
            self.assertEqual(set(grouped), {'a', 'b'})

    def test_distinct_sequences_resolve_identity(self):
        rows = [source('a', songs=('Bertha',)), source('b', songs=('Jack Straw',))]
        matched, grouped, extra = reconcile(rows, [event('x', songs=('Jack Straw',)), event('y', songs=('Bertha',))])
        self.assertEqual(matched['a']['url'], 'https://example.org/y')
        self.assertFalse(grouped or extra)

    def test_unknown_calendar_day_is_not_first_of_month(self):
        self.assertEqual(day_of('1967-05-00 [Mon]'), '1967-05')
        self.assertEqual(day_of('1970-00-00'), '1970')
        self.assertEqual(day_of('1967/05/12/1'), '1967-05-12')

    def test_recording_dates_require_identifier_evidence(self):
        def row(key):
            return dict(provider='Archive.org', key=key, title='1977-05-08', grouped_date='1977-05-08')
        self.assertIsNone(recording_date(row('gd1967-00-00.sbd')))
        self.assertIsNone(recording_date(row('gd1995-08-09.sbd')))
        self.assertEqual(recording_date(row('gd77-05-08.sbd')), '1977-05-08')
        self.assertIsNone(recording_date(row('gd1977-02-30.sbd')))

    def test_utf8_index_and_category_filtering(self):
        html = '''<table id="datatable_events"><tbody><tr><td><a href="/events/1">1969-01-01</a></td>
        <td><a href="/venues/1">Café, City</a></td><td>Grateful Dead</td><td><b>Set 1:</b> Bertha</td>
        <td>Canceled</td><td>GD</td><td>1</td></tr></tbody></table>'''
        rows = parse(html.encode(), 1969)
        self.assertEqual(rows[0]['venue_label'], 'Café, City')
        self.assertEqual(rows[0]['program_fingerprint'], fingerprint('Bertha'))
        matched, _, extra = reconcile([source('a', venue='Café')], rows)
        self.assertFalse(matched or extra)


class CorpusTests(unittest.TestCase):
    def test_every_source_show_and_index_identity_is_accounted_for(self):
        payload = gzip.decompress((ROOT / 'sources/gdshowsdb.json.gz').read_bytes())
        lock = json.loads((ROOT / 'sources/gdshowsdb-lock.json').read_text(encoding='utf-8'))
        self.assertEqual(sha(payload), lock['facts_sha256'])
        raw = json.loads(payload)
        ledger = json.loads((ROOT / 'curation/import-ledger.json').read_text(encoding='utf-8'))
        mapped = [s for s in ledger['shows'] if s['source'] == 'gdshowsdb']
        self.assertEqual(Counter(s[':uuid'] for s in raw), Counter(s['source_uuid'] for s in mapped))
        covered = set()
        for show in ledger['shows']:
            self.assertTrue((ROOT / 'data' / show['path']).is_file())
            if show.get('jerrybase_url'):
                covered.add(show['jerrybase_url'])
            covered.update(show['identity_group'])
        index = json.loads((ROOT / 'sources/jerrybase-index.json').read_text(encoding='utf-8'))['events']
        self.assertEqual(covered, {s['url'] for s in index if s['category'] == 'Public'})

    def test_imported_program_order_and_titles_are_conserved(self):
        rows = json.loads(gzip.decompress((ROOT / 'sources/gdshowsdb.json.gz').read_bytes()))
        raw = {r[':uuid']: r for r in rows}
        songs = E.parse(str(ROOT / 'data/songs.xml')).getroot()
        titles = {s.get('id'): s.findtext('b:title', namespaces=N) for s in songs.findall('b:song', N)}
        ledger = json.loads((ROOT / 'curation/import-ledger.json').read_text(encoding='utf-8'))
        for entry in ledger['shows']:
            if entry['source'] != 'gdshowsdb' or entry['preserved_existing']:
                continue
            root = E.parse(str(ROOT / 'data' / entry['path'])).getroot()
            source_sets = raw[entry['source_uuid']][':sets']
            sets = root.findall('b:program/b:set', N)
            self.assertEqual(len(sets), len(source_sets), entry['show'])
            for st, original in zip(sets, source_sets):
                performances = st.findall('b:performance', N)
                self.assertEqual(len(performances), len(original[':songs']), entry['show'])
                for p, s in zip(performances, original[':songs']):
                    self.assertEqual(fingerprint(p.get('titleVariant') or titles[p.get('song')]), fingerprint(s[':name']), entry['show'])
                    if not s[':segued']:
                        self.assertEqual(p.get('transition'), 'unknown')

    def test_recording_placement_is_conservative_and_complete(self):
        placements = json.loads(gzip.decompress((ROOT / 'curation/recording-placement.json.gz').read_bytes()))
        lock = json.loads((ROOT / 'sources/recordings-lock.json').read_text(encoding='utf-8'))
        self.assertEqual(len(placements), lock['records'])
        by_date = Counter(E.parse(str(p)).getroot().get('date') for p in (ROOT / 'data/shows').rglob('*.xml'))
        self.assertEqual(len({(p['provider'], p['key']) for p in placements}), len(placements))
        for p in placements:
            if p['reason'] is None:
                self.assertEqual(p['identifier_date'], p['original_grouped_date'])
                self.assertEqual(by_date[p['identifier_date']], 1)


if __name__ == '__main__':
    unittest.main()
