"""Rebuild the finite curation inventory from the current XML, entirely offline."""
import argparse
from collections import Counter, defaultdict
import csv
import gzip
import json
from pathlib import Path

from lxml import etree as E
from collect_index import fingerprint

ROOT = Path(__file__).resolve().parents[1]
N = {'b': 'urn:berthaml:1'}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data', type=Path, default=ROOT / 'data')
    p.add_argument('--output', type=Path, default=ROOT / 'curation')
    args = p.parse_args()
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    ledger = json.loads((out / 'import-ledger.json').read_text(encoding='utf-8'))
    imports = {s['show']: s for s in ledger['shows']}
    index = {r['url']: r for r in json.loads((ROOT / 'sources' / 'jerrybase-index.json').read_text(encoding='utf-8'))['events']}
    song_root = E.parse(str(args.data / 'songs.xml')).getroot()
    titles = {s.get('id'): s.findtext('b:title', namespaces=N) for s in song_root.findall('b:song', N)}
    by_year = defaultdict(Counter)
    issues, totals, flags, statuses = [], Counter(), Counter(), Counter()
    for path in sorted(args.data.glob('shows/*/*.xml')):
        root = E.parse(str(path)).getroot()
        sid = root.get('id')
        entry = imports.get(sid, {})
        program = root.find('b:program', N)
        status = root.find('b:record', N).get('status')
        todo = []
        if status not in ('reviewed', 'verified'):
            todo.append('record-unreviewed')
        if root.find('b:lineup', N) is None:
            todo.append('lineup-unresearched')
        if program.get('coverage') != 'complete':
            todo.append('setlist-incomplete-or-unconfirmed')
        if root.xpath('.//b:set[@kind="unknown" or @mode="unknown"]', namespaces=N):
            todo.append('set-roles-and-modes-unresearched')
        comparison = index.get(entry.get('jerrybase_url'))
        current_program = fingerprint(''.join(p.get('titleVariant') or titles[p.get('song')]
            for p in root.findall('.//b:performance', N)))
        if comparison and current_program != comparison['program_fingerprint']:
            todo.append('source-program-difference')
        if entry.get('identity_group'):
            todo.append('individual-event-association-unresolved')
        if entry.get('identity_unconfirmed'):
            todo.append('event-absent-from-comparison-index')
        if entry.get('source_terminal_segue'):
            todo.append('terminal-segue-needs-evidence')
        if len(root.get('date')) < 10:
            todo.append('date-day-unknown')
        if entry.get('program_available') and not program.findall('b:set', N):
            todo.append('source-program-not-transcribed')
        if entry.get('preserved_existing'):
            todo.append('existing-seed-facts-require-review')
        performances = len(root.findall('.//b:performance', N))
        recordings = len(root.findall('b:sources/b:recording', N))
        counts = dict(shows=1, performances=performances, recording_references=recordings,
                      no_program=int(program.get('coverage') == 'none'),
                      reviewed=int(status in ('reviewed', 'verified')))
        totals.update(counts)
        by_year[root.get('date')[:4]].update(counts)
        statuses[status] += 1
        flags.update(todo)
        issues.append(dict(show_id=sid, date=root.get('date'), status=status,
                           file=path.relative_to(args.data).as_posix(),
                           performances=performances, recording_references=recordings,
                           needs_review=';'.join(todo),
                           source_key=entry.get('source_key', ''),
                           source_url=entry.get('jerrybase_url') or '',
                           identity_group=' '.join(entry.get('identity_group', []))))
    placements = json.loads(gzip.decompress((out / 'recording-placement.json.gz').read_bytes()))
    unassigned = Counter(p['reason'] for p in placements if p['reason'])
    registry_counts = {}
    for kind, singular in [('people', 'person'), ('songs', 'song'), ('venues', 'venue'), ('releases', 'release')]:
        root = E.parse(str(args.data / (kind + '.xml'))).getroot()
        registry_counts[kind] = len(root.findall('b:' + singular, N))
    summary = dict(scope=dict(first='1967-01-01', last='1995-07-09'), totals=dict(totals),
                   statuses=dict(statuses), registries=registry_counts, issue_counts=dict(flags),
                   years={y: dict(c) for y, c in sorted(by_year.items())},
                   comparison_index_public_events=ledger['index_public_events'],
                   comparison_index_excluded_categories={k: v for k, v in ledger['index_categories'].items() if k != 'Public'},
                   source_programs_identical=sum(s.get('program_agrees') is True for s in ledger['shows']),
                   recording_input_records=len(placements), unassigned_recording_references=dict(unassigned),
                   canonical_curation_complete=False)
    (out / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    with (out / 'shows.csv').open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(issues[0]))
        writer.writeheader()
        writer.writerows(issues)
    text = ['# BerthaML curation inventory', '',
            'Scope: 1 January 1967 through the last concert, 9 July 1995. This is a populated research corpus; canonical curation is incomplete.', '',
            f'**{totals["shows"]:,} show records; {totals["performances"]:,} performance entries; '
            f'{totals["recording_references"]:,} placed historical recording references.**', '',
            'The XML status is authoritative. Imported drafts and skeletons have not been promoted by database agreement or by successful validation.', '',
            f'Registries: {registry_counts["people"]} people, {registry_counts["songs"]} song entries, '
            f'{registry_counts["venues"]} provisional venue identities, {registry_counts["releases"]} release. '
            'People, writer/lead credits and releases still include the supplied sample/seed material; their completeness is not claimed.', '',
            '| Year | Shows | Performances | Recording references | No setlist | Reviewed |',
            '| --- | ---: | ---: | ---: | ---: | ---: |']
    for y, c in sorted(by_year.items()):
        text.append(f'| {y} | {c["shows"]} | {c["performances"]} | {c["recording_references"]} | {c["no_program"]} | {c["reviewed"]} |')
    text += ['', '## Outstanding show work', '',
             'Counts overlap. `shows.csv` lists the exact records and evidence links.', '',
             '| Review category | Shows |', '| --- | ---: |']
    text += [f'| {k} | {v} |' for k, v in sorted(flags.items())]
    text += ['', '## Recording placement', '',
             f'All {len(placements):,} input provider listings are accounted for in `recording-placement.json.gz`. '
             'Listings are not deduplicated tape lineages. A date shared by multiple concerts does not justify assigning a recording to either concert.', '',
             '| Unassigned reason | Listings |', '| --- | ---: |']
    text += [f'| {k} | {v} |' for k, v in sorted(unassigned.items())]
    text += ['', '## Completion criteria', '',
             '1. Adjudicate event identities, cancellations and disputed dates with cited evidence; explicitly exclude spurious events.',
             '2. Resolve the program differences and same-day associations. Verify set roles, modes, segues and reprises; retain documented unknowns.',
             '3. Research actual show/set personnel and guests; membership periods alone do not establish attendance.',
             '4. Curate song aliases, composition credits and vocalists, and merge venue aliases only with physical-site evidence.',
             '5. Complete official-release/edition/track mappings and recording/track coverage where evidence exists. New official releases remain ongoing work.',
             '6. Record evidence-backed dispositions for unavailable facts, then review each record and both validators. No fabricated value is required to close a documented unknown.', '',
             'The historical event scope is finite. New evidence can revise it; ongoing releases and tape discoveries have no historical cutoff.', '']
    (out / 'summary.md').write_text('\n'.join(text), encoding='utf-8')
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
