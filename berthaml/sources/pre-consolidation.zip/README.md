# BerthaML

An XML vocabulary for describing Grateful Dead shows of the Jerry Garcia era (1965-05-05 to 1995-07-09). One file per show, plus four shared registries.

## Layout

```
schemas/
  berthaml.xsd    driver: validates any BerthaML file
  common.xsd      ID formats, dates, closed vocabularies, record/citation block
  show.xsd        <show>
  people.xsd      <people>
  songs.xsd       <songs>
  venues.xsd      <venues>
  releases.xsd    <releases>
data/
  people.xml
  songs.xml
  venues.xml
  releases.xml
  shows/YYYY/<show-id>.xml
tools/
  validate.py
  requirements.txt
```

Namespace: `urn:berthaml:1`. Schemas are XSD 1.0, so they load in .NET `System.Xml.Schema`, libxml2/lxml and Xerces.

## Setup

From the repository root in PowerShell:

```powershell
py -m venv .venv; .\.venv\Scripts\python.exe -m pip install -r tools\requirements.txt
```

## Validate

```powershell
.\.venv\Scripts\python.exe tools\validate.py data
```

Add `--strict` to fail on warnings. Output lines are `ERROR file:line: message` or `WARN  file:line: message`, followed by a summary. Exit code 0 means no errors.

## Design

### Registries instead of enumerations

People, songs, venues and releases are open-ended (hundreds of guests, ~500 songs), so they are not enumerated in the schema. They live in registry files, and show files refer to them by ID. ID formats are fixed by pattern:

| Kind | Pattern | Example |
| :---- | :---- | :---- |
| Person | `p-...` | `p-garcia` |
| Song | `s-...` | `s-dire-wolf` |
| Venue | `v-...` | `v-harpur-college` |
| Release | `rel-...` | `rel-dicks-picks-08` |
| Show | `gdYYYY-MM-DD[-suffix]` | `gd1970-05-02`, `gd1966-xx-xx` |

XSD 1.0 cannot check references across files, so `tools/validate.py` does.

Instruments, set kinds, modes, transitions and record status are genuinely closed and are enumerated in `common.xsd`.

### Personnel inheritance

```
show <lineup>
  -> set <personnel> (replaces) or <personnelChanges> (delta)
    -> performance <personnel> (replaces) or <personnelChanges> (delta)
```

`<personnelChanges>` holds `<remove>`, `<add>` and `<change>`. `<change>` replaces that person's instrument list. Use `<personnel>` where the stage empties out, e.g. Drums.

The show's `<lineup>` is authoritative. Membership periods in `people.xml` are only for pre-filling lineups and for warnings.

### Durations belong to tracks, not performances

A duration is a measurement of a specific recording or release, and track boundaries differ between sources. One track often spans several performances (Good Lovin' > Drums > Good Lovin'). So durations sit on `<track>` elements, which list the performance IDs they cover:

- circulating recordings: `<recording>/<track>` inside the show file
- official releases: `<release>/<track>` in `releases.xml`, with `show` and `covers`

### Sandwiches and reprises

A performance that resumes an earlier one sets `continues` to the earlier performance's ID. Named suites (That's It For The Other One, Weather Report Suite) are catalog entries of `kind="suite"`; their parts carry `<partOf>`.

### Transitions

`transition` on each performance is `segue`, `stop` or `unknown`. It describes what happened on stage. Tape cuts are recorded on recordings, not here.

### Uncertainty and provenance

- Each file has `<record status="skeleton|draft|reviewed|verified">` with `<cite>` entries.
- Most facts accept `certainty="certain|probable|uncertain"`.
- Dates accept year or year-month precision when the day is unknown.
- `<program coverage="complete|partial|none">` states how much of the setlist is known.

### Deliberately not stored

Values derivable from the data are left out so they cannot drift: set totals, set counts, play counts, first and last played dates, era names, day of week, chronological index.

## Validator checks

Schema validation, then:

- references to people, songs, venues, releases and shows resolve
- show ID agrees with the date and the file name; no duplicate IDs
- two shows on one date both have `<slot>` and an ID suffix
- sets ordered soundcheck, set, encore; numbered 1..n within each kind
- `mode="mixed"` sets state a mode on every performance
- personnel changes are consistent with what is inherited
- `continues` targets an earlier performance of the same song
- lead vocalists are on stage (warning)
- lineup members fall inside a membership period, and active members missing from a lineup are flagged (warnings)
- release and recording tracks cover existing performance or event IDs
- song credits use either a person ID or a text name
