# HANDOFF

## Current state

BerthaML schema set, seed registries, one sample show and a validator. The sample data validates with no errors or warnings. The validator catches all 24 injected faults in the negative test run.

The source was a Gemini draft (single `berthaml.xsd` plus an example for 1970-05-02). It was rebuilt rather than patched; see Decisions.

## Decisions

1. Registries instead of `xs:enumeration` for people, songs, venues, releases. The draft enumerated players in the schema, which means editing the schema for every new guest.
2. One namespace, `urn:berthaml:1`, with one module per root element and a driver schema. The draft used `http://gratefuldead.org/...`, a domain not under the project's control. The URN works as an identifier but is not a registered URN namespace; switch to a URI on a domain you own if the project is published.
3. XSD 1.0, not 1.1, so the schemas work in .NET. Co-constraints and cross-file references are in `tools/validate.py`.
4. Durations moved from performances to tracks on specific recordings or releases.
5. Transition values reduced to `segue|stop|unknown`. The draft's `tape-cut` mixed recording facts into performance facts, and its `segue` versus `into` distinction was not defined consistently.
6. Instruments are physical instruments only. The draft had `rhythm-guitar`, `lead-vocals` and `backing-vocals` as instruments. Lead vocals are a per-performance `<lead>` element with catalog defaults.
7. Personnel inheritance across show, set and performance. The draft only overrode per song, so its acoustic set reverted to the full electric lineup after the first song.
8. Derived values removed (date parts, day of week, set totals, set counts, play counts, first/last played, era, chronological index).
9. `certainty`, record `status` and `<cite>` added, because much early-era data is uncertain.

## Corrections to the draft's data

- Its 1970-05-02 example was largely invented: Dawson guesting on Friend Of The Devil and Garcia on pedal steel during Dire Wolf are not supported by the sources checked; the acoustic set was 11 songs, not 4; set 2 continued well past Cosmic Charlie; there was a third set. The sample show here is rebuilt from cited sources.
- Its era table put Donna Godchaux's start at March 1972. Seed data here uses 1971-12-31.

## Commands run

```
python3 tools/validate.py data            -> 0 errors, 0 warnings, exit 0
python3 tools/validate.py data --strict   -> exit 0
negative test script (24 single-fault mutations of data/) -> 24 caught
```

Run on Linux, Python 3.13, lxml 6.1.3. Not yet run on Windows or against .NET `System.Xml.Schema`.

## Files

- `schemas/common.xsd`, `show.xsd`, `people.xsd`, `songs.xsd`, `venues.xsd`, `releases.xsd`, `berthaml.xsd`
- `data/people.xml`, `songs.xml`, `venues.xml`, `releases.xml`, `shows/1970/gd1970-05-02.xml`
- `tools/validate.py`, `tools/requirements.txt`
- `README.md`, `HANDOFF.md`

## Unresolved

- Membership dates in `people.xml` are seed values from general knowledge, not checked against a source. Lesh's start (1965-06), Constanten's dates and Hornsby's dates are marked `probable`.
- Default lead vocalists in `songs.xml` are seed values.
- Sample show: acoustic set personnel beyond Garcia and Weir is unresearched; which NRPS members joined Cold Jordan is unresearched; Garcia's pedal steel with NRPS is marked `probable`. Two release track mappings are inferred and marked `probable`. Durations for some tracks are missing.
- The segue after Candyman comes from two sources, but one circulating track list shows a tuning track after it. Unresolved.
- The validator does not yet check that every performance has a lead vocalist or catalog default, nor that teases name a different song from the one being played.
- The set-kind ordering rule ignores `kind="other"`.

## Next recommended action

Write the skeleton generator: given a list of show dates and venues, emit `status="skeleton"` show files with lineups pre-filled from membership periods. Before that, verify `people.xml` membership dates against a cited source, since every skeleton inherits them.
