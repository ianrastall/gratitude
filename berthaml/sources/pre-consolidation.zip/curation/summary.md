# BerthaML curation inventory

Scope: 1 January 1967 through the last concert, 9 July 1995. This is a populated research corpus; canonical curation is incomplete.

**2,236 show records; 39,544 performance entries; 18,584 placed historical recording references.**

The XML status is authoritative. Imported drafts and skeletons have not been promoted by database agreement or by successful validation.

Registries: 14 people, 404 song entries, 559 provisional venue identities, 1 release. People, writer/lead credits and releases still include the supplied sample/seed material; their completeness is not claimed.

| Year | Shows | Performances | Recording references | No setlist | Reviewed |
| --- | ---: | ---: | ---: | ---: | ---: |
| 1967 | 141 | 201 | 39 | 100 | 0 |
| 1968 | 126 | 529 | 96 | 57 | 0 |
| 1969 | 149 | 1527 | 316 | 25 | 0 |
| 1970 | 146 | 2078 | 306 | 11 | 0 |
| 1971 | 81 | 1793 | 379 | 1 | 0 |
| 1972 | 86 | 2229 | 378 | 0 | 0 |
| 1973 | 72 | 1884 | 469 | 0 | 0 |
| 1974 | 40 | 1059 | 342 | 0 | 0 |
| 1975 | 4 | 54 | 34 | 0 | 0 |
| 1976 | 41 | 941 | 306 | 0 | 0 |
| 1977 | 60 | 1233 | 434 | 0 | 0 |
| 1978 | 81 | 1584 | 596 | 0 | 0 |
| 1979 | 75 | 1597 | 633 | 0 | 0 |
| 1980 | 87 | 2103 | 808 | 0 | 0 |
| 1981 | 83 | 1841 | 867 | 0 | 0 |
| 1982 | 61 | 1312 | 766 | 0 | 0 |
| 1983 | 66 | 1357 | 1086 | 0 | 0 |
| 1984 | 64 | 1281 | 1128 | 0 | 0 |
| 1985 | 71 | 1402 | 1418 | 0 | 0 |
| 1986 | 46 | 879 | 727 | 0 | 0 |
| 1987 | 85 | 1693 | 1111 | 0 | 0 |
| 1988 | 80 | 1563 | 952 | 0 | 0 |
| 1989 | 73 | 1449 | 1101 | 0 | 0 |
| 1990 | 74 | 1489 | 1192 | 0 | 0 |
| 1991 | 77 | 1463 | 1068 | 0 | 0 |
| 1992 | 55 | 1011 | 555 | 0 | 0 |
| 1993 | 81 | 1544 | 667 | 0 | 0 |
| 1994 | 84 | 1584 | 470 | 0 | 0 |
| 1995 | 47 | 864 | 340 | 0 | 0 |

## Outstanding show work

Counts overlap. `shows.csv` lists the exact records and evidence links.

| Review category | Shows |
| --- | ---: |
| date-day-unknown | 2 |
| event-absent-from-comparison-index | 2 |
| existing-seed-facts-require-review | 1 |
| individual-event-association-unresolved | 26 |
| lineup-unresearched | 2235 |
| record-unreviewed | 2236 |
| set-roles-and-modes-unresearched | 2041 |
| setlist-incomplete-or-unconfirmed | 2235 |
| source-program-difference | 108 |
| source-program-not-transcribed | 1 |
| terminal-segue-needs-evidence | 1 |

## Recording placement

All 19,297 input provider listings are accounted for in `recording-placement.json.gz`. Listings are not deduplicated tape lineages. A date shared by multiple concerts does not justify assigning a recording to either concert.

| Unassigned reason | Listings |
| --- | ---: |
| existing-curated-file-preserved | 7 |
| identifier-date-disagrees-with-runtime-group | 15 |
| identifier-date-unknown-or-out-of-scope | 374 |
| multiple-shows-on-date | 127 |
| no-confirmed-date-entry | 191 |

## Completion criteria

1. Adjudicate event identities, cancellations and disputed dates with cited evidence; explicitly exclude spurious events.
2. Resolve the program differences and same-day associations. Verify set roles, modes, segues and reprises; retain documented unknowns.
3. Research actual show/set personnel and guests; membership periods alone do not establish attendance.
4. Curate song aliases, composition credits and vocalists, and merge venue aliases only with physical-site evidence.
5. Complete official-release/edition/track mappings and recording/track coverage where evidence exists. New official releases remain ongoing work.
6. Record evidence-backed dispositions for unavailable facts, then review each record and both validators. No fabricated value is required to close a documented unknown.

The historical event scope is finite. New evidence can revise it; ongoing releases and tape discoveries have no historical cutoff.
